'use strict';
//require thu vien
const express = require('express');
const bodyParser = require('body-parser');
const crypto = require('crypto');
const mongoose = require('mongoose');
const bcryptjs = require('bcryptjs');
const moment = require('moment');
//require model
var HocVien = mongoose.model('HocVien');
var GiangVien = mongoose.model('GiangVien');
var Khoa = mongoose.model('Khoa');
var Lop = mongoose.model('Lop');
var DanhSachDiemDanh = mongoose.model('DanhSachDiemDanh');

var tong_ngay=[]
//get 1 hoc vien tu Hoc Vien Collection
exports.gethocvien = function(req, res) {
  var ma_hv = req.query.ma_hv;
  var ma_lop = "";
  var hocvien = [];
  HocVien.find({ma_hv:ma_hv},{_id:false,matkhau_hv:false,mssv:false,cmnd_hv:false},function(err, data) {
    if (err){
    	res.send(err);
    }	
    hocvien.push(data[0]);
    ma_lop = data[0].ma_lop;
    /*Lop.find({ma_lop:ma_lop}, function(err,doc){
    	if(err){
    		res.send(err);
    	}
    	hocvien.push(doc[0]);
    	console.log(hocvien);
    }); */
    Lop.aggregate([
    	{$match: {ma_lop:ma_lop}},
        {$lookup: {
            from: 'GiangVien',
            localField: 'ma_gv',
            foreignField: 'ma_gv',
            as: 'ma_gv'
        	}
    	},
    	{ $project : {
    		"_id":0,
    		"lop_246":1,
    		"ma_khoa_hoc":1,
    		"loailop":1, 
    		"ma_gv": {
    			"hoten_gv":1,
    			"email_gv":1
    			}
    		} 
    	}	
        ],function (err,doc) {
            if (err) throw err;
            // console.log(res[0].ma_gv);
            hocvien.push(doc[0]);
            console.log(hocvien);
            res.send(hocvien);
        });
  });
};
// get so ngay cua hoc vien 
exports.getSoNgayHoc = function(req, res){
var ma_hv = req.query.ma_hv;
var ma_lop="";
tong_ngay=[];
	console.log("Mã học viên: "+ma_hv);
	HocVien.find({ma_hv:ma_hv}, function(err, hocvien){
		if(err){
			res.send(err);
			//console.log(err);
		}
		//console.log("Mã lớp: "+hocvien[0].ma_lop);
		ma_lop = hocvien[0].ma_lop;
		//Tinh tong so buoi cua lop hoc
		DanhSachDiemDanh.aggregate([
			{$match: {ma_lop:ma_lop}},
			{$group:{
					_id:
					{
						"ma_lop":"$ma_lop",
						"ngay":"$ngay"
					}
				}
			},
			{$count:"tong_ngay_lop"}
		], function(err,doc){
			if(err) console.log(err);
			//console.log(doc[0]);
			//tong_ngay.push(doc[0]);
			if(doc[0]==undefined){
				tong_ngay.push({"tong_ngay_lop":"0"});
			}else{
				tong_ngay.push(doc[0]);
			}
			//Tinh tong so buoi cua hoc vien
			DanhSachDiemDanh.aggregate([
				{$match: {ma_lop:ma_lop,ma_hv:ma_hv}},
				{$group:{
						_id:
						{
							"ma_lop":"$ma_lop",
							"ma_hv":"$ma_hv",
							"ngay":"$ngay"
						}
					}
				},
				{$count:"tong_ngay_hv"}
			], function(err,doc){
				if(err) console.log(err);
				//console.log(doc[0]);
				//tong_ngay.push(doc[0]);
				if(doc[0]==undefined){
					tong_ngay.push({"tong_ngay_hv":"0"});
				}else{
					tong_ngay.push(doc[0]);
				}
				console.log("Mảng là:");
				console.log(tong_ngay);
				res.send(tong_ngay);
			});
		});
	});
};
//get diem so danh gia
exports.getTongDiemDanhGia = function(req,res){
	var ma_hv = req.query.ma_hv;
	var ma_lop = "";
	HocVien.find({ma_hv:ma_hv}, function(err, hocvien){
		if(err){
			res.send(err);
			//console.log(err);
		}
		ma_lop = hocvien[0].ma_lop;
		DanhSachDiemDanh.aggregate([
				{$match: {ma_lop:ma_lop,ma_hv:ma_hv}},
				{$group:{
					_id:
						{
							"ma_lop":"$ma_lop",
							"ma_hv":"$ma_hv"
						},
					diem_danhgia: {$avg: "$diem_danhgia"}
					}
				}
			], function(err,doc){
				if(err) console.log(err);
				if(doc[0]==undefined){
					doc=[{"diem_danhgia":"0"}]
				}
				console.log("Doc la: "+doc); //lam tron so
				res.send(doc);
			});
	});	
}

//Dang nhap cho Hoc Vien
exports.dangnhap_hv = function(req,res,done){
	//console.log(req.body);
	var ma_hv = req.body.ma_hvien;
	var matkhau = req.body.matkhau_hvien;
	console.log("Mã: "+ma_hv+" pass: "+matkhau);
	HocVien.find({ma_hv : ma_hv,matkhau_hv : matkhau}, function(err, hocvien) {
	    if(err){
	    	res.send("<"); // fact: the account is not exit
	    }else{
	    	if(hocvien.length>0){
	    		res.json(hocvien);
	    	}else{
	    		res.send("<");
	    	}
	    }
	 //    var passRecord=hocvien[0].matkhau_hv;
		// if(matkhau===passRecord){
			
		// }else{
		// 	res.send("<"+JSON.stringify(hocvien));
		// }
		// console.log(hocvien[0].matkhau_hv);   
  	});
};

//Doi mat khau cho hoc vien
exports.doimk_hv = function(req,res){
	// console.log(req);
	var ma_hv = req.body.ma_hvien;
	var old_pass = req.body.old_pass;
	var new_pass = req.body.new_pass;
	HocVien.find({ma_hv:ma_hv, matkhau_hv:old_pass} ,function(err,hocvien){
		if(err){
			//console.log(err);
			res.send("e");
		}else{
			if(hocvien.length > 0){
				HocVien.updateOne({ma_hv:ma_hv},{$set:{matkhau_hv:new_pass}},function(err,data){
					if(err){
						//console.log("Error: "+err);
						res.send("e");
					}else{
						res.send("y");
					}
				})
			}else{
				res.send("n");
			}
		}
	});
}
exports.getinfolop=function(req,res){
	var ma = req.query.ma_lop;
	Lop.find({ma_lop:ma},{_id:false},function(err,data){
		if(err){
			throw err;
		}else{
			// console.log(data);
			res.send(data);
		}
	})
}
/*Functions for update info*/
exports.getdiemhv=function(req,res){
	var ma = req.query.ma_hv;
	var arr = [];
	var obj = {};
	HocVien.find({ma_hv:ma},{_id:false,matkhau_hv:false},function(err,data){
		if(err){
			throw err;
		}else{
			var lt_cc = data[0].diemthi_lt_cc;
			var th_cc = data[0].diemthi_th_cc;
			var lt_cn = data[0].diemthi_lt_cn;
			var th_cn = data[0].diemthi_th_cn;

			if(lt_cc == null || lt_cc == ""){
				lt_cc=-1;
			}
			if(th_cc == null || th_cc == ""){
				th_cc=-1;
			}
			
			if(lt_cn == null || lt_cn == ""){
				lt_cn=-1;
			}
			if(th_cn == null || th_cn == ""){
				th_cn=-1;
			}

			obj['diemthi_lt_cc'] = lt_cc;
			obj['diemthi_th_cc'] = th_cc;
			obj['diemthi_lt_cn'] = lt_cn;
			obj['diemthi_th_cn'] = th_cn;
			arr.push(obj);
			res.send(arr);
		}
	})
}
/*Functions for update info*/
exports.getinfohv=function(req,res){
	var ma = req.query.ma_hv;
	HocVien.find({ma_hv:ma},{_id:false,matkhau_hv:false},function(err,data){
		if(err){
			throw err;
		}else{
			// console.log(data);
			res.send(data);
		}
	})
}

exports.updateinfohv = function(req,res){
	var ma = req.body.ma_hvien;
	var hoten = req.body.hoten;
	var ngaysinh = req.body.ngaysinh;
	var quequan = req.body.quequan;
	var cmnd = req.body.cmnd;
	var sdt = req.body.sdt;
	var email = req.body.email;
	var gioitinh = req.body.gioitinh;
	var thi_cc = req.body.thi_cc;
	var thi_cn = req.body.thi_cn;
	var ns="";
	console.log(req.body);
	var reg_ns = /^(?:(?:31(\/|-|\.)(?:0?[13578]|1[02]))\1|(?:(?:29|30)(\/|-|\.)(?:0?[1,3-9]|1[0-2])\2))(?:(?:1[6-9]|[2-9]\d)?\d{2})$|^(?:29(\/|-|\.)0?2\3(?:(?:(?:1[6-9]|[2-9]\d)?(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|[2468][048]|[3579][26])00))))$|^(?:0?[1-9]|1\d|2[0-8])(\/|-|\.)(?:(?:0?[1-9])|(?:1[0-2]))\4(?:(?:1[6-9]|[2-9]\d)?\d{2})$/;
    var reg_ht = /^[a-zA-Z_\sÀÁÂÃÈÉÊÌÍÒÓÔÕÙÚĂĐĨŨƠàáâãèéêìíòóôõùúăđĩũơƯĂẠẢẤẦẨẪẬẮẰẲẴẶẸẺẼỀẾỂưăạảấầẩẫậắằẳẵặẹẻẽềếểỄỆỈỊỌỎỐỒỔỖỘỚỜỞỠỢỤỦỨỪễệỉịọỏốồổỗộớờởỡợụủứừỬỮỰỲỴÝỶỸửữựỳỵỷỹ]{1,}$/;
    var reg_email = /^([a-z0-9_\.-]+)@([\da-z\.-]+)\.([a-z\.]{2,6})$/;
    var reg_sdt = /^[0-9]{10}$/;
    var reg_cmnd = /^[0-9]{9}$/;

	if(thi_cc=="true"){
		thi_cc=true;
	}else{
		thi_cc=false;
	}

	if(thi_cn=="true"){
		thi_cn=true;
	}else{
		thi_cn=false;
	}

    if(!reg_ns.test(ngaysinh)){
    	res.send("fd");
    }else if(!reg_ht.test(hoten)){
    	res.send("fn");
    }else if(!reg_email.test(email)){
    	res.send("fe");
    }else if(!reg_sdt.test(sdt)){
    	res.send("fp");
    }else if(!reg_cmnd.test(cmnd)){
    	res.send("fcm");
    }else{

    	ns=moment(moment(ngaysinh, ["DD-MM-YYYY", "DD/MM/YYYY","DD.MM.YYYY"])).format('YYYY-MM-DD');
    	HocVien.updateOne({ma_hv:ma},{$set:{quequan_hv:quequan,ngaysinh_hv:ns,gioitinh_hv:gioitinh,
    								cmnd_hv:cmnd,sdt_hv:sdt,email_hv:email,thi_cc:thi_cc,thi_cn:thi_cn}}, 
    	function(err,res_up){
    		if(err){
    			res.send("f");
    		}else{
    			res.send("t");
    		}
    	})
    }
}
