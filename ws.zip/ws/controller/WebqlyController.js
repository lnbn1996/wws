'use strict';
//require thu vien
const express = require('express');
const bodyParser = require('body-parser');
const crypto = require('crypto');
const mongoose = require('mongoose');
const bcryptjs = require('bcryptjs');
const moment = require('moment');

const excel4node = require('excel4node');
const exceljs = require('exceljs')
var xlstojson = require("xls-to-json-lc");
var xlsxtojson = require("xlsx-to-json-lc");

var validator = require("validator");
var async = require('async');
/* xu ly multer*/
var fs = require('fs');
var multer = require('multer');
var storage = multer.diskStorage({ //multers disk storage settings
        destination: function (req, file, cb) {
            cb(null, './uploads/')
        },
        filename: function (req, file, cb) {
            var datetimestamp = Date.now();
            cb(null, 'ImportDSHV-'+file.fieldname + '-' + datetimestamp + '.' + file.originalname.split('.')[file.originalname.split('.').length -1])
        }
});
var upload = multer({ //multer settings
        storage: storage,
        fileFilter : function(req, file, callback) { //file filter
        if (['xls', 'xlsx'].indexOf(file.originalname.split('.')[file.originalname.split('.').length-1]) === -1)
        {
            return callback(new Error('Wrong extension type'));
        }
        callback(null, true);
    }
}).single('file');
//require model
var HocVien = mongoose.model('HocVien');
var GiangVien = mongoose.model('GiangVien');
var Khoa = mongoose.model('Khoa');
var Lop = mongoose.model('Lop');
var DanhSachDiemDanh = mongoose.model('DanhSachDiemDanh');
var Hv_BackUp = mongoose.model('Hv_BackUp');

/// lay thong tin cac khoa
exports.getkhoa=function(req,res){
    Khoa.find({},function(err,data){
        if(err){
            res.send("f");
        }else{
            if(data.length>0){
                res.send(data);
            }else{
                res.send("f");
            }
        }
    }).sort({ma_khoa_hoc:-1})
}
//lay ten cac lop theo khoa
exports.get_cac_lop=function(req,res){
    var ma =req.query.makhoa;
    Lop.find({ma_khoa_hoc:ma},function(err,data){
        if(err){
            res.send("f");
        }else{
            if(data.length>0){
                console.log(data);
                res.send(data);
            }else{
                res.send("f");
            }
        }
    })
}

exports.delkhoaHoc=function(req,res){
    var ma = req.body.makhoa;
    // console.log(ma);
    Lop.find({ma_khoa_hoc:ma}, function(err,data){
        if(err){
            res.send("f");
        }else{
            if(data.length>0){
                res.send("not");
            }else{
                Khoa.deleteOne({ma_khoa_hoc:ma},function(err,res1){
                    if(err){
                        // console.log(err);
                        res.send("f");
                    }else{
                        // console.log(res1);
                        res.send("t");
                    }
                })
            }
        }
    })
}

//update ngay khai giang cho khoa
exports.updateKhoa = function(req,res){
    var ma = req.body.ma_khoa;
    // xu ly ngay khai giang
    var date = req.body.ngay;
    var ngay = moment(moment(date, 'DD-MM-YYYY')).format('YYYY-MM-DD');
    var now = moment().format('YYYY-MM-DD');
    // xu ly ngay ket thuc
    var datekt = req.body.ngaykt;
    if(datekt!=""){
        var ngay_kt = moment(moment(datekt, 'DD-MM-YYYY')).format('YYYY-MM-DD');   
    }else{
        var ngay_kt = datekt;
    }
    Khoa.find({ma_khoa_hoc:ma},function(err,data){
        var nkg_old=moment(data[0].ngaykhaigiang).format('YYYY-MM-DD');
        if(ngay!=nkg_old && ngay<now){
            res.send("w");
        }else if((moment(moment(datekt, 'DD-MM-YYYY')).diff(moment(moment(date, 'DD-MM-YYYY')),'days'))<60){
            // console.log(moment(moment(datekt, 'DD-MM-YYYY')).diff(moment(moment(date, 'DD-MM-YYYY')),'days'));
            res.send("d");
        }else if(ngay==nkg_old || ngay > now){
            Khoa.updateOne({ma_khoa_hoc:ma},{$set: {ngaykhaigiang:ngay,ngayketthuc:ngay_kt} }, function(err,res1){
                if(err){
                    console.log(err);
                    res.send("f");
                }else{
                    console.log(res1);
                    res.send("t");
                }
            })
        }
    })
}
/// lay thong tin cac khoa
exports.get_tt_khoa=function(req,res){
    var ma =  req.body.ma;
    Khoa.find({ma_khoa_hoc:ma},function(err,data){
        if(err){
            res.send("f");
        }else{
            if(data.length>0){
                res.send(data);
            }else{
                res.send("f");
            }
        }
    })
}
/// insert khoa moi
exports.insert_khoa=function(req,res){
    var date = req.body.ngay;
    var datekt = req.body.ngaykt;
    var ngay = moment(moment(date, 'DD-MM-YYYY')).format('YYYY-MM-DD');
    var now = moment().format('YYYY-MM-DD');
    if(ngay < now){
        res.send("w");
    }else if((moment(moment(datekt, 'DD-MM-YYYY')).diff(moment(moment(date, 'DD-MM-YYYY')),'days'))<60){
        res.send("d");
    }else{
        Khoa.find({},function(err,data){
            if(err){
                res.send("f");
            }else{
                var id = data.length;
                for (var i=0; i<=data.length-1;i++){
                    var makhoa_tmp=data[i].ma_khoa_hoc;
                    if(id==makhoa_tmp){
                        id=parseInt(makhoa_tmp)+1;
                    }
                } 
                Khoa.create({ma_khoa_hoc:id,ngaykhaigiang:ngay},function(err,res1){
                    if(err){
                        // console.log(err);
                        res.send("f");
                    }else{
                        // console.log(res1);
                        res.send("t");
                    }
                })
            }
        })
    }
}
//lay ds lop theo khoa
exports.dslop_khoa=function(req,res){
    var ma = parseInt(req.body.makhoa);
    // console.log(ma);
    Lop.aggregate([
        {$match: {ma_khoa_hoc:ma}},
        {$lookup: {
            from: 'HocVien',
            localField: 'ma_lop',
            foreignField: 'ma_lop',
            as: 'ma_lop_chung'
            }
        },
        {$sort:
            {'ma_lop': -1}
        }
        ],function (err,data) {

        if(err){
            // console.log(err);
            res.send("f");
        }
        if(data.length>0){
            // console.log(data);
            res.send(data);
        }else{
            // console.log(data);
            res.send("f");
        }

    });
}
//get ds gv
exports.get_ds_gv=function(req,res){
    GiangVien.find({},{_id:false,matkhau_gv:false},function(err,data){
        if(err){
            res.send("f");
        }else{
            if(data.length>0){
                res.send(data);
            }else{
                res.send("e");
            }
        }
    })
}

//get ds gv for select option
exports.get_dsgv_SelectOption=function(req,res){
    GiangVien.find({quyen_gv:1},{_id:false,matkhau_gv:false},function(err,data){
        if(err){
            res.send("f");
        }else{
            if(data.length>0){
                res.send(data);
            }else{
                res.send("e");
            }
        }
    })
}

//update cho lop hoc
exports.updateLop = function(req,res){
    var ma_lop = req.body.ma_lop;
    var magv = req.body.magv;
    var lop_246 = req.body.lop_246;
    var loailop = req.body.loailop;
    var ngay_thi_cc = req.body.ngay_thi_cc;
    var ngay_thi_cn = req.body.ngay_thi_cn;
    var ngay_nhan_bang = req.body.ngay_nhan_bang;
    var now = moment().format('YYYY-MM-DD');
    var now_insert = moment().format('DD-MM-YYYY');
    console.log(now);
    // xu ly ngay nhan bang
    if(ngay_nhan_bang!=""){
        var date_nb = moment(moment(ngay_nhan_bang, ["DD-MM-YYYY", "DD/MM/YYYY","DD.MM.YYYY"])).format('YYYY-MM-DD');
        if(date_nb<now){
            ngay_nhan_bang = now_insert;
        }else{
            ngay_nhan_bang = moment(moment(ngay_nhan_bang, ["DD-MM-YYYY", "DD/MM/YYYY","DD.MM.YYYY"])).format('DD-MM-YYYY');
        }
    }else{
        ngay_nhan_bang="";
    }
    // xu ly ngay thi chung chi
    if(ngay_thi_cc!=""){
        var date_cc = moment(moment(ngay_thi_cc, ["DD-MM-YYYY", "DD/MM/YYYY","DD.MM.YYYY"])).format('YYYY-MM-DD');
        if(date_cc<now){
            ngay_thi_cc = now_insert;
        }else{
            ngay_thi_cc = moment(moment(ngay_thi_cc, ["DD-MM-YYYY", "DD/MM/YYYY","DD.MM.YYYY"])).format('DD-MM-YYYY');
        }
    }
    //xu ly ngay thi chung nhan
    if(ngay_thi_cn!=""){
        var date_cn = moment(moment(ngay_thi_cn, ["DD-MM-YYYY", "DD/MM/YYYY","DD.MM.YYYY"])).format('YYYY-MM-DD');
        if(date_cn < now){
            ngay_thi_cn = now_insert;
        }else{
            ngay_thi_cn = moment(moment(ngay_thi_cn, ["DD-MM-YYYY", "DD/MM/YYYY","DD.MM.YYYY"])).format('DD-MM-YYYY');
        }
    }
    //update thong tin lop
    Lop.updateOne({ma_lop:ma_lop},
        {$set: {ngay_thi_cc:ngay_thi_cc,ngay_thi_cn:ngay_thi_cn,ngay_nhan_bang:ngay_nhan_bang,ma_gv:magv,lop_246:lop_246,loailop:loailop}
    }, function(err,res1){
        if(err){
            res.send("f");
        }else{
            res.send("t");
        }
    })  
}
//Them lop moi
exports.themLop=function(req,res){
    var ma_khoa = req.body.ma_khoa;
    // console.log("Mã khoá: "+ma_khoa);
    var magv = req.body.magv;
    var lop_246 = req.body.lop_246;
    var loailop = req.body.loailop;
    var ngay_thi_cc = req.body.ngay_thi_cc;
    var ngay_thi_cn = req.body.ngay_thi_cn;
    var ngay_nb = req.body.ngay_nhan_bang;
    var now = moment().format('YYYY-MM-DD');

    if(ngay_thi_cc!=""){
        var date_cc = moment(moment(ngay_thi_cc, ["DD-MM-YYYY", "DD/MM/YYYY","DD.MM.YYYY"])).format('DD-MM-YYYY');
        var date_cc_tmp = moment(moment(ngay_thi_cc, ["DD-MM-YYYY", "DD/MM/YYYY","DD.MM.YYYY"])).format('YYYY-MM-DD');
    }else{
        var date_cc = "";
    }
    if(ngay_thi_cn!=""){
        var date_cn = moment(moment(ngay_thi_cn, ["DD-MM-YYYY", "DD/MM/YYYY","DD.MM.YYYY"])).format('DD-MM-YYYY');
        var date_cn_tmp = moment(moment(ngay_thi_cn, ["DD-MM-YYYY", "DD/MM/YYYY","DD.MM.YYYY"])).format('YYYY-MM-DD');
    }else{
        var date_cn = "";
    }
    if(ngay_nb!=""){
        var date_nb = moment(moment(ngay_nb, 'DD-MM-YYYY')).format('DD-MM-YYYY');
        var date_nb_tmp = moment(moment(ngay_nb, ["DD-MM-YYYY", "DD/MM/YYYY","DD.MM.YYYY"])).format('YYYY-MM-DD'); 
    }else{
        var date_nb = "";
    }

    Lop.find({},function(err,data){
        if(err){
            res.send("f");
        }else{
            var len = data.length;
            var pad = "C0000";
            var id="";

            if(len<10){
                id = pad.substring(0, pad.length - 1)+len;
            }else if(len<100){
                id = pad.substring(0, pad.length - 2)+len;              
            }else if(len<1000){
                id = pad.substring(0, pad.length - 3)+len;
            }else{
                id = pad.substring(0, pad.length - 4)+len;            
            }

            for (var i=0; i<=data.length-1;i++){
                var malop_tmp=data[i].ma_lop;
                if(id==malop_tmp){
                    var num=parseInt(malop_tmp.substring(malop_tmp.indexOf("C")+1,malop_tmp.length))+1;
                    if(num<10){
                        id = pad.substring(0, pad.length - 1)+num;
                    }else if(num<100){
                        id = pad.substring(0, pad.length - 2)+num;              
                    }else if(num<1000){
                        id = pad.substring(0, pad.length - 3)+num;
                    }else{
                        id = pad.substring(0, pad.length - 4)+num;            
                    } 
                }
            }            
            if((date_cc_tmp>now || ngay_thi_cc=="") && (date_nb_tmp>now || ngay_nb=="") && ((date_cn_tmp>now || ngay_thi_cn=="")) ){
                Lop.create({ma_lop:id,lop_246:lop_246,ma_khoa_hoc:ma_khoa,loailop:loailop,ma_gv:magv,ngay_thi_cc:date_cc,ngay_thi_cn:date_cn,ngay_nhan_bang:date_nb},
                    function(err,res1){
                    if(err){
                        // console.log(err);
                        res.send("f");
                    }else{
                        // console.log(res1);
                        res.send("t");
                    }
                });       
            }else{
                res.send("n");
            }   
        }
    })     
}
//xoa lop
exports.delLop=function(req,res){
    var ma = req.body.malop;
    // console.log(ma);
    HocVien.find({ma_lop:ma}, function(err,data){
        if(err){
            res.send("f");
        }else{
            if(data.length>0){
                res.send("not");
            }else{
                Lop.deleteOne({ma_lop:ma},function(err,res1){
                    if(err){
                        console.log(err);
                        res.send("f");
                    }else{
                        console.log(res1);
                        res.send("t");
                    }
                })
            }
        }
    })
}

/*Import - Export*/

//export bang diem mau
exports.exportDshvMau = function(req,res){
    var ma = req.query.ma_lop;
    var khoa = req.query.ma_khoa;

    var wb = new excel4node.Workbook();

    var ws = wb.addWorksheet('danhsachhocvien');

    var style = wb.createStyle({
      font: {
        size: 14,
        bold:true,
      },
      alignment:{
        horizontal:'center',
        vertical:'center',
      }
    });
    var style2 = wb.createStyle({
      font: {
        size: 16,
        bold:true
      }
    });
    var style3 = wb.createStyle({
      font: {
        size: 14,
        bold:true
      },
      alignment: {
        horizontal:'center',
        vertical:'center'
      }
    });
    // Tieu de - hang 1
    ws.cell(1, 1, 1, 7,true).string('Danh Sách Học Viên').style(style2);
    //Ma lop & Ma khoa - hang 2
    ws.cell(2, 1).string('Mã lớp').style(style); //Hàng 2 - Cột 1
    ws.cell(2, 2).string(ma);  //Hàng 2 - Cột 2
    ws.cell(2, 3).string('Mã khoá').style(style); //Hàng 2 - Cột 3
    ws.cell(2, 4).string(khoa);  //Hàng 2 - Cột 4
    // Thong tin hoc vien - hang 3 - n
    ws.cell(3, 1).string('Họ Tên').style(style);ws.column(1).setWidth(15);
    ws.cell(3, 2).string('Giới tính(Nữ/Nam)').style(style3);ws.column(2).setWidth(25);
    ws.cell(3, 3).string('Ngày Sinh(DD-MM-YYYY)').style(style3);ws.column(3).setWidth(25);
    ws.cell(3, 4).string('Quê Quán').style(style);ws.column(4).setWidth(15);
    ws.cell(3, 5).string('Số CMND').style(style);ws.column(5).setWidth(15);
    ws.cell(3, 6).string('Email').style(style);ws.column(6).setWidth(15);
    ws.cell(3, 7).string('Số Điện Thoại').style(style);ws.column(7).setWidth(15);
    ws.cell(3, 8).string('MSSV').style(style);ws.column(8).setWidth(15);
    wb.write('danhsachlop_'+ma+'.xlsx', res);                
}
//export danh sach
exports.importDanhSachHv = function(req,res){
        var exceltojson; //Initialization

        upload(req,res,function(err){
        if(err){
            res.send("f");
            return;
        }
        /** Multer gives us file info in req.file object */
        if(!req.file){
            res.send("n"); // no file passed
            return;
        }
        // console.log(req.file.path);

        //bat dau xu ly file excel
        if(req.file.originalname.split('.')[req.file.originalname.split('.').length-1] === 'xlsx'){
            exceltojson = xlsxtojson;
        } else {
            exceltojson = xlstojson;
        }
        try {
            var wb = new exceljs.Workbook();
            wb.xlsx.readFile(req.file.path).then(function(){

                var sh = wb.getWorksheet("danhsachhocvien");
                // console.log("Tổng số row: "+sh.rowCount);
                //get ma lop va ma khoa
                if(sh.getRow(2).getCell(2).value=="" ||sh.getRow(2).getCell(4).value==""){
                    res.send("f");
                }else{
                    //xu ly ma khoa ma lop
                    var ma_lop = sh.getRow(2).getCell(2).value;
                    // console.log("Ma lop: "+ma_lop);
                    var ma_khoa = sh.getRow(2).getCell(4).value;
                    // console.log("Ma khoa: "+ma_khoa);

                    //xu ly back-up document hoc vien
                    var obj=""
                    HocVien.find({ma_lop:ma_lop,ma_khoa_hoc:ma_khoa},{_id:false,__v:false},function(err,hv){
                        if(err) throw err;
                        if(hv.length>0){
                            var now = moment().toISOString();
                            var i = 0
                            async.whilst(
                              function() { return i <= hv.length-1; },
                              function(callback) {
                                Hv_BackUp.create({ma_hv:hv[i].ma_hv,matkhau_hv:hv[i].matkhau_hv,
                                            hoten_hv:hv[i].hoten_hv,gioitinh_hv:hv[i].gioitinh_hv,
                                            ngaysinh_hv:hv[i].ngaysinh_hv,quequan_hv:hv[i].quequan_hv,
                                            cmnd_hv:hv[i].cmnd_hv,email_hv:hv[i].email_hv,
                                            sdt_hv:hv[i].sdt_hv,mssv:hv[i].mssv,ma_lop:hv[i].ma_lop,ma_khoa_hoc:hv[i].ma_khoa_hoc,
                                            thi_cc:hv[i].thi_cc,thi_cn:hv[i].thi_cn,
                                            diemthi_lt_cc:hv[i].diemthi_lt_cc,diemthi_th_cc:hv[i].diemthi_th_cc,
                                            diemthi_lt_cn:hv[i].diemthi_lt_cn,diemthi_th_cn:hv[i].diemthi_th_cn,
                                            thoi_gian_xoa:now},
                                    function(err_bk,res_bk){
                                    if (err_bk) callback(err_bk);
                                    // console.log(res_bk);
                                    i++;
                                    callback();
                                })
                              },
                              function(err) {
                                if (err) console.log(err);
                                else{
                                  // done;
                                }
                              }
                            ); //end async whilst  
                        } //end if (hv.length<0)
                    }) // end fine back up ttin hoc vien khi xoa

                    /* Xoa all hoc vien cua lop - khoa*/
                    HocVien.deleteMany({ma_lop:ma_lop,ma_khoa_hoc:ma_khoa},function(err_del,res_del){
                            if(err_del) throw err_del;
                            // console.log(res_del);
                    })

                    /* Them moi toan bo hoc vien cua lop - khoa */
                    //xu ly password
                    var pass = "1234567"
                    var mk = crypto.createHash('md5').update(pass).digest("hex");
                    //
                    var pad = "0000";
                    //Get all the rows data [1st and 2nd column]
                    HocVien.find({ma_khoa_hoc:ma_khoa},function(err,data){
                        var mahv = "";
                        if(err){
                            res.send("f");
                        }else{
                            if(data.length>0){
                                var len = data.length+1;
                            }else{
                                var len = 1;
                            }
                            // console.log(data);
                            // console.log("So luong hv: "+len);
                            
                            var i = 4;

                            async.whilst(
                              function() { return i <= sh.rowCount; },
                              function(callback) {
                                //delete upsertData._id;
                                var ht = sh.getRow(i).getCell(1).value;
                                var gt = sh.getRow(i).getCell(2).value;
                                var ngaysinh = sh.getRow(i).getCell(3).value;
                                var qq = sh.getRow(i).getCell(4).value;
                                var cmnd = sh.getRow(i).getCell(5).value;
                                var email_hv = sh.getRow(i).getCell(6).value;
                                var sdt = sh.getRow(i).getCell(7).value;
                                var mssv = sh.getRow(i).getCell(8).value;
                                // console.log("I: "+i)
                                // console.log("Ho ten: "+ht);            
                                 //xu ly ngay sinh
                                if(ngaysinh!=""){
                                    var date = moment(moment(ngaysinh, ["DD-MM-YYYY", "DD/MM/YYYY","DD.MM.YYYY"])).format('YYYY-MM-DD');
                                    if(date=="Invalid date" || date ==false ){
                                        var ns = "";
                                    }else{
                                        var ns = date;
                                    }
                                }
                                // //xu ly email
                                if(email_hv.text==undefined){
                                    var email = email_hv;
                                }else{
                                    var email = email_hv.text;
                                }
                                if(cmnd.length<9 || cmnd.length>9){
                                    cmnd="";
                                }
                                //xu ly ma hoc vien
                                if(len<10){
                                    mahv = pad.substring(0, pad.length - 1)+len+"K"+ma_khoa;
                                }else if(len<100){
                                    mahv = pad.substring(0, pad.length - 2)+len+"K"+ma_khoa;              
                                }else if(len<1000){
                                    mahv = pad.substring(0, pad.length - 3)+len+"K"+ma_khoa;
                                }else{
                                    mahv = pad.substring(0, pad.length - 4)+len+"K"+ma_khoa;            
                                }
                                HocVien.create({ma_hv:mahv,matkhau_hv:mk,
                                                hoten_hv:ht,gioitinh_hv:gt,
                                                ngaysinh_hv:ns,quequan_hv:qq,
                                                cmnd_hv:cmnd,email_hv:email,
                                                sdt_hv:sdt,mssv:mssv,ma_lop:ma_lop,ma_khoa_hoc:ma_khoa,
                                                thi_cc:false,thi_cn:false,
                                                diemthi_lt_cc:"",diemthi_th_cc:"",
                                                diemthi_lt_cn:"",diemthi_th_cn:""},
                                    function(err,res1){
                                    if (err) callback(err);
                                    i++;
                                    len++;
                                    callback();
                                })
                              },
                              function(err) {
                                if (err) console.log(err);
                                else{
                                  // done;
                                    res.send("t");
                                }
                              }
                            );   
                        } //end else sau khi find HocVien
                    }) //end  HocVien find request                
                }
                try {
                    console.log(req.file.path);
                    fs.unlinkSync(req.file.path); //xoa file
                } catch(e) {
                        //error deleting the file
                    console.log(e);
                }
            });
        } catch (e){
            res.send("c"); //loi file bi hu
        }
    });
}
//get 1 hv
exports.ql_getHv=function(req,res){
    var ma = req.body.ma_hv;
    HocVien.find({ma_hv:ma},{matkhau_hv:false}, function(err,data){
        if(err){
            res.send("f");
        }else{
            if(data.length<0){
                res.send("f");
            }else{
                // console.log(data
                res.send(data);
            }
        }
    })
}
//update hoc vien
exports.update_ql_hv = function(req,res){
    var ma = req.body.ma_hv;
    var ht = req.body.ht;
    var gt = req.body.gt;
    var ns = req.body.ns;
    var qq = req.body.qq;
    var cmnd = req.body.cmnd;
    var email = req.body.email;
    var sdt = req.body.sdt;
    var mssv = req.body.mssv;

    var thi_cc = req.body.thi_cc;
    var thi_cn = req.body.thi_cn;

    if(ns==""){
         HocVien.updateOne({ma_hv:ma},
            {$set: {hoten_hv: ht,gioitinh_hv:gt,ngaysinh_hv:ns,quequan_hv:qq,cmnd_hv:cmnd,email_hv:email,sdt_hv:sdt,mssv:mssv,thi_cc:thi_cc,thi_cn:thi_cn}
         }, function(err,res1){
            if(err){
                console.log(err);
                res.send("f");
             }else{
                console.log(res1);
                res.send("t");
            }
        })       
    }else{
        var date = moment(moment(ns, 'DD-MM-YYYY')).format('YYYY-MM-DD');
        HocVien.updateOne({ma_hv:ma},
            {$set: {hoten_hv: ht,gioitinh_hv:gt,ngaysinh_hv:date,quequan_hv:qq,cmnd_hv:cmnd,email_hv:email,sdt_hv:sdt,mssv:mssv,thi_cc:thi_cc,thi_cn:thi_cn}
        }, function(err,res1){
            if(err){
                // console.log(err);
                res.send("f");
            }else{
                console.log(res1);
                res.send("t");
            }
        })             
    }
}
//Them mot hoc vien
exports.them_mot_hv = function(req,res){
    var ma_lop = req.body.ma_lop;
    var ma_khoa = req.body.ma_khoa;
    var ht = req.body.ht;
    var gt = req.body.gt;
    var ns = req.body.ns;
    var qq = req.body.qq;
    var cmnd = req.body.cmnd;
    var email = req.body.email;
    var sdt = req.body.sdt;
    var mssv = req.body.mssv;
    var thi_cc = req.body.thi_cc;
    var thi_cn = req.body.thi_cn;
    HocVien.find({ma_khoa_hoc:ma_khoa},function(err,data){
        var mahv = "";
        if(err){
            res.send("f");
        }else{
            if(data.length>0){
                var len = data.length;
            }else{
                var len = 1;
            }
            var pad="0000";
            //xu ly ma hoc vien
            if(len<10){
                mahv = pad.substring(0, pad.length - 1)+len+"K"+ma_khoa;
            }else if(len<100){
                mahv = pad.substring(0, pad.length - 2)+len+"K"+ma_khoa;              
            }else if(len<1000){
                mahv = pad.substring(0, pad.length - 3)+len+"K"+ma_khoa;
            }else{
                mahv = pad.substring(0, pad.length - 4)+len+"K"+ma_khoa;            
            }
            if(cmnd.length<9 || cmnd.length>9){
                cmnd="";
            }
            //xu ly password
            var pass = "1234567"
            var mk = crypto.createHash('md5').update(pass).digest("hex");
            for (var i=0; i<=data.length-1;i++){
                // console.log(data[i].ma_hv);
                var mahv_tmp=data[i].ma_hv;
                if(mahv==mahv_tmp){
                    var num=parseInt(mahv_tmp.substring(0,mahv_tmp.indexOf("K")))+1;
                    if(num<10){
                        mahv = pad.substring(0, pad.length - 1)+num+"K"+ma_khoa;
                    }else if(num<100){
                        mahv = pad.substring(0, pad.length - 2)+num+"K"+ma_khoa;              
                    }else if(num<1000){
                        mahv = pad.substring(0, pad.length - 3)+num+"K"+ma_khoa;
                    }else{
                        mahv = pad.substring(0, pad.length - 4)+num+"K"+ma_khoa;            
                    } 
                }
                // console.log("Lần thứ "+i+" "+mahv);
            }               

            if(ns==""){
                HocVien.create({ma_hv:mahv,matkhau_hv:mk,
                    hoten_hv:ht,gioitinh_hv:gt,
                    ngaysinh_hv:ns,quequan_hv:qq,
                    cmnd_hv:cmnd,email_hv:email,
                    sdt_hv:sdt,mssv:mssv,ma_lop:ma_lop,ma_khoa_hoc:ma_khoa,
                    thi_cc:thi_cc,thi_cn:thi_cn,
                    diemthi_lt_cc:"",diemthi_th_cc:"",
                    diemthi_lt_cn:"",diemthi_th_cn:""
                    },
                    function(err,res1){
                        if(err){
                            res.send("f");
                        }else{
                            res.send("t");
                    }
                })  
            }else{
                var date = moment(moment(ns, 'DD-MM-YYYY')).format('YYYY-MM-DD');
                HocVien.create({ma_hv:mahv,matkhau_hv:mk,
                    hoten_hv:ht,gioitinh_hv:gt,
                    ngaysinh_hv:date,quequan_hv:qq,
                    cmnd_hv:cmnd,email_hv:email,
                    sdt_hv:sdt,mssv:mssv,ma_lop:ma_lop,ma_khoa_hoc:ma_khoa,
                    thi_cc:thi_cc,thi_cn:thi_cn,
                    diemthi_lt_cc:"",diemthi_th_cc:"",
                    diemthi_lt_cn:"",diemthi_th_cn:""},
                    function(err,res1){
                        if(err){
                            console.log(err);
                            res.send("f");
                        }else{
                            res.send("t");
                    }
                })                  
            }
        } //end else sau khi find HocVien
    }) //end  HocVien find request         
}//end function

//xoa hoc vien
exports.delHv=function(req,res){
    var ma = req.body.lop;
    var ma_hv = req.body.hv;
    // console.log(ma+" "+hv);
    DanhSachDiemDanh.find({ma_lop:ma,ma_hv:ma_hv}, function(err,data){
        if(err){
            res.send("f");
        }else{
            if(data.length>0){
                res.send("not");
            }else{
                HocVien.find({ma_hv:ma_hv,ma_lop:ma},function(err,hv){
                    if(err){
                        res.send("f");
                    }else{
                        if(hv.length>0){
                            var now1 = moment().toISOString();
                            Hv_BackUp.create({ma_hv:hv[0].ma_hv,matkhau_hv:hv[0].matkhau_hv,
                                    hoten_hv:hv[0].hoten_hv,gioitinh_hv:hv[0].gioitinh_hv,
                                    ngaysinh_hv:hv[0].ngaysinh_hv,quequan_hv:hv[0].quequan_hv,
                                    cmnd_hv:hv[0].cmnd_hv,email_hv:hv[0].email_hv,
                                    sdt_hv:hv[0].sdt_hv,mssv:hv[0].mssv,ma_lop:hv[0].ma_lop,ma_khoa_hoc:hv[0].ma_khoa_hoc,
                                    thi_cc:hv[0].thi_cc,thi_cn:hv[0].thi_cn,
                                    diemthi_lt_cc:hv[0].diemthi_lt_cc,diemthi_th_cc:hv[0].diemthi_th_cc,
                                    diemthi_lt_cn:hv[0].diemthi_lt_cn,diemthi_th_cn:hv[0].diemthi_th_cn,
                                    thoi_gian_xoa:now1},
                                function(err_bk,res_bk){
                                    if (err_bk) throw err_bk;
                                    console.log(res_bk);
                                    HocVien.deleteOne({ma_hv:ma_hv,ma_lop:ma},function(err_del,res_bk){
                                        if(err_del){
                                            res.send("f");
                                        }else{
                                            res.send("t");
                                        }
                                    })
                            })
                        }else{
                            res.send("ne");
                        }
                    }
                })
            }
        }
    })
}
//cap nhat thong tin giang vien
exports.ql_capnhat_ttgv = function(req,res){
    var ma = req.body.ma_gv;
    var ht = req.body.hoten;
    var cmnd = req.body.cmnd;
    var email = req.body.email;
    var sdt = req.body.sdt;
    var quyen = req.body.quyen;
    GiangVien.updateOne({ma_gv:ma},{$set: {hoten_gv:ht,cmnd_gv:cmnd,email_gv:email,sdt_gv:sdt,quyen_gv:quyen}}, function(err,res1){
        if(err){
            console.log(err);
            res.send("f");
        }else{
            console.log(res1);
            res.send("t");
        }
    })    
}
//them giang vien
exports.ql_them_gv = function(req,res){

    var ht = req.body.hoten;
    var cmnd = req.body.cmnd;
    var email = req.body.email;
    var sdt = req.body.sdt;
    var quyen = req.body.quyen;
    var ma="";
    GiangVien.find({},function(err,data){
        if(err){
            res.send("f");
        }else{
            if(data.length>0){
                var len=data.length+1;
            }else{
                var len=1;
            }
            var pad="0000";
            //xu ly ma giang vien
            if(len<10){
                ma = pad.substring(0, pad.length - 1)+len;
            }else if(len<100){
                ma = pad.substring(0, pad.length - 2)+len;              
            }else if(len<1000){
                ma = pad.substring(0, pad.length - 3)+len;
            }else{
                ma = pad.substring(0, pad.length - 4)+len;            
            }            
        }
        GiangVien.create({ma_gv:ma,hoten_gv:ht,cmnd_gv:cmnd,email_gv:email,sdt_gv:sdt,quyen_gv:quyen}, function(err,res1){
            if(err){
                console.log(err);
                res.send("f");
            }else{
                console.log(res1);
                res.send("t");
            }
        })
    })    
}
//xoa giang vien
exports.delGv=function(req,res){
    var ma = req.body.gv;
    Lop.find({ma_gv:ma}, function(err,data){
        if(err){
            res.send("f");
        }else{
            if(data.length>0){
                res.send("not");
            }else{
                GiangVien.deleteOne({ma_gv:ma},function(err,res1){
                    if(err){
                        // console.log(err);
                        res.send("f");
                    }else{
                        // console.log(res1);
                        res.send("t");
                    }
                })
            }
        }
    })
}