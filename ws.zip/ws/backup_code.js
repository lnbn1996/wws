//import bang diem mau
exports.importBangDiem = function(req,res){
        var exceltojson; //Initialization

        upload(req,res,function(err){
        if(err){
            res.send("f");
            return;
        }
        /** Multer gives us file info in req.file object */
        if(!req.file){
            res.send("n"); // no file passed
            return;
        }
        // console.log(req.file.path);

        //bat dau xu ly file excel
        if(req.file.originalname.split('.')[req.file.originalname.split('.').length-1] === 'xlsx'){
            exceltojson = xlsxtojson;
        } else {
            exceltojson = xlstojson;
        }
        try {
            /*exceltojson({
                    input: req.file.path, //the same path where we uploaded our file
                    output: null, //since we don't need output.json
                    sheet: "bangdiem",
                    lowerCaseHeaders:true
            }, function(err,result){ //upload thanh cong va co the lay du lieu
                if(err) {
                    res.send("f"); //loi data null, khong doc duoc file excel
                }
                console.log(result);
                res.send("t");
            });*/
            var wb = new exceljs.Workbook();
            wb.xlsx.readFile(req.file.path).then(function(){

                var sh = wb.getWorksheet("bangdiem");
                console.log("Tổng số row: "+sh.rowCount);
                //Get all the rows data [1st and 2nd column]
                /*for (var i = 2; i <= sh.rowCount; i++) {
                    var ma = sh.getRow(i).getCell(1).value;
                    var ht = sh.getRow(i).getCell(2).value;
                    var th = sh.getRow(i).getCell(3).value;
                    var lt = sh.getRow(i).getCell(4).value;
                    console.log("Mã: "+ma+" - "+"Tên: "+ht+" - "+"lt: "+lt+" - "+"th: "+th);
                    HocVien.updateOne({ma_hv:ma},{$set: {diemthi_lt:lt,diemthi_th:th}},function(err,res1){
                        if(err){
                            console.log(err);
                        }else{
                            console.log(res1);
                            console.log("Mã: "+ma+" - "+"Tên: "+ht+" - "+"lt: "+lt+" - "+"th: "+th);
                        }
                    })
                }*/

                var i = 2;

                async.whilst(
                  function() { return i <= sh.rowCount; },
                  function(callback) {
                    //delete upsertData._id;
                    HocVien.updateOne(
                      { ma_hv: sh.getRow(i).getCell('A').value},
                      {
                        $set : {
                          diemthi_lt:sh.getRow(i).getCell('C').value,
                          diemthi_th:sh.getRow(i).getCell('D').value
                        }
                      },
                      { upsert: true},
                      function(err,data) {
                        if (err) callback(err);
                        // console.log(sh.getRow(i).getCell('A').value+" "+sh.getRow(i).getCell('C').value);
                        // console.log(data);
                        i++;
                        callback();
                      }
                    );

                  },
                  function(err) {
                    if (err) console.log(err);
                    else{
                      // done;
                        res.send("t");
                    }
                  }
                );
            });
            // try {
            //     fs.unlinkSync(req.file.path); //xoa file
            // } catch(e) {
            //         //error deleting the file
            // }
        } catch (e){
            res.send("c"); //loi file bi hu
        }
    });
}