var mongoose = require('mongoose');
var validator = require('validator');
var Schema = mongoose.Schema;

var DanhSachDiemDanhSchema = new Schema({
    ma_hv: { type:String,trim: true, Required: true },
    ma_lop: { type: String,trim: true, Required: true },
	hoten_hv: { type:String },
	ngay: {type: Date},
	hoctraibuoi: {type: Boolean},
	diem_danhgia: {type: Number, min: 1, max: 10},
	nhanxet: {type: String }
});

module.exports = mongoose.model('DanhSachDiemDanh',DanhSachDiemDanhSchema,'DanhSachDiemDanh');