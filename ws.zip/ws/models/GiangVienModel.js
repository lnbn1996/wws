var mongoose = require('mongoose');
var validator = require('validator');
var Schema = mongoose.Schema;

var GiangVienSchema = new Schema({
    ma_gv: { type:String,trim: true, Required: true },
    matkhau_gv: {type: String, trim:true, minlength: 6, maxlength: 18 },
	hoten_gv: { type:String },
	cmnd_gv: {type:String, minlength: 9,maxlength: 9 },
	email_gv: { type:String, Required: true,validate: (value) => {
      return validator.isEmail(value)
    	}
	},
	sdt_gv: { type:String, minlength: 10,maxlength: 11 },
	quyen_gv: {type:Number}
});

module.exports = mongoose.model('GiangVien',GiangVienSchema,'GiangVien');