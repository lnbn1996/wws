var expr = require('express'),
	app = expr(),
	port = process.env.port || 6006,
	mongoose = require('mongoose'),
	bodyParser = require('body-parser');

var fs = require('fs');
var key = fs.readFileSync('cer/privkey.pem');
var cert = fs.readFileSync('cer/cert.pem');
var full_cert = fs.readFileSync('cer/fullchain.pem');
var ca = fs.readFileSync('cer/chain.pem');

var options = {
key: key,
cert: cert,
ca:ca,
requestCert: false,
rejectUnauthorized: false
};
var http = require('http'); 
var https = require('https');

//Models
var HocVien = require('./models/HocVienModel'),
	GiangVien = require('./models/GiangVienModel'),
	Khoa = require('./models/KhoaModel'),
	Lop = require('./models/LopModel'),
	DanhSachDiemDanh = require('./models/DanhSachDiemDanhModel'),
	Hv_BackUp = require('./models/Hv_BackUpModel');

mongoose.Promise = global.Promise;
mongoose.connect('mongodb://localhost:27017/QLyKhoaHocChungChi');
//mongoose.connect('mongodb://app.eemc2.xyz/:27017/QLyKhoaHocChungChi');

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});

var routes = require('./routes/AppRoutes');
routes(app);
/*
app.enable('trust proxy');

app.use(function (req, res, next) {
        if (req.secure) {
                // request was via https, so do no special handling
		next();
        } else {
                // request was via http, so redirect to https
                res.redirect('https://' + req.headers.host + req.url);
        }
});*/

app.use(function(req, res){
	res.status(404).send({url: req.originalUrl + ' not found'})
});

//app.listen(port);
//http.createServer(app).listen(port);
https.createServer(options,app).listen(port);
console.log('Web Service -  RESTful web services with Nodejs started on: ' + port);

