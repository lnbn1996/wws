function checkLocalStorage(){
	var hours = 1; // Reset when storage is more than 24hours
    var now = new Date().getTime();
    var setupTime = localStorage.getItem('expTime');
    if (setupTime != null) {
        if(now-setupTime > hours*60*60*1000) {
            localStorage.clear();
        }
    }
}
function checkSessionLogin(){
	if(localStorage.getItem('ma_gv')==null){
        if(sessionStorage.getItem('ma_gv')==null){
		  window.location='../dangnhap.html';
        }
	}
}

function loadHeadFoot(){
    $(function(){
        $('.footer').load('../footer.html');
        if(sessionStorage.getItem('quyen_gv')=="1" || localStorage.getItem('quyen_gv')=="1"){
            $('.menu').load('../header_gd.html');
        }else if(sessionStorage.getItem('quyen_gv')=="2" || localStorage.getItem('quyen_gv')=="2" ){
            $('.menu').load('../header_ql.html');
        }
    })

}
function checkAjax(){
    if(sessionStorage.getItem('ma_gv')!=null){
        $(document).ajaxError(function(){
            alert("Hệ thống đã có lỗi, mời bạn thử lại sau");
        });
    }else if(localStorage.getItem('ma_gv')!=null){
        $(document).ajaxError(function(){
            alert("Hệ thống đã có lỗi, mời bạn thử lại sau");
        });
    }
}
function callTable(name){
    $(document).ready(function() {
        var table = $('#'+name).DataTable({
        "language": {
            "lengthMenu": "Hiển thị _MENU_ dòng dữ liệu trên một trang:",
            "info": "Hiển thị _START_ trong tổng số _TOTAL_ dòng dữ liệu:",
            "infoEmpty": "Dữ liệu rỗng",
            "emptyTable": "Chưa có dữ liệu nào ",
            "processing": "Đang xử lý ",
            "search": "Tìm kiếm: ",
            "loadingRecords": "Đang load dữ liệu",
            "zeroRecords": "Không tìm thấy dữ liệu",
            "infoFiltered": "(Được từ tổng số _MAX_ dòng dữ liệu",
            "paginate": {
                "first": "|<",
                "last": ">|",
                "next": ">>",
                "previous": "<<"
                }
            },
        "lengthMenu": [[5,10,15,20,25,-1],[5,10,15,20,25,"Tất cả"]]
        });
    });
}

function DangXuat(){
    localStorage.clear();
    sessionStorage.clear();
    window.location='../dangnhap.html';
}
function deleteConfirm(){
    if(confirm("Bạn có chắc chắn muốn xóa!")){
        return true;
    }
    else{
        return false;
    }
}
